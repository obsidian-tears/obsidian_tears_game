#!/bin/bash
case "$1" in
	Username *) exec echo $GIT_USERNAME; ;
	Password *) exec echo $GIT_PASSWORD; ;
esac
